using System;

namespace Pr_20
{
    public class Class1
    {
    }
}
